#ifndef CLIENTLOC_H
#define CLIENTLOC_H

extern int find_client_loc(char loc[2],const char ip[16]);

#endif
