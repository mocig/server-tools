#include "tai.h"

void tai_uint(struct tai *t,unsigned int u)
{
  t->x = u;
}
