#ifndef QLOG_H
#define QLOG_H

#include "uint16.h"

extern void qlog(const char *,uint16,const char *,const char *,const char *,const char *);

#endif
