#ifndef PRINTPACKET_H
#define PRINTPACKET_H

#include "stralloc.h"

extern unsigned int printpacket_cat(stralloc *,char *,unsigned int);

#endif
