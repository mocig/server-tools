#ifndef DD_H
#define DD_H

extern int dd(const char *,const char *,char *);

#endif
